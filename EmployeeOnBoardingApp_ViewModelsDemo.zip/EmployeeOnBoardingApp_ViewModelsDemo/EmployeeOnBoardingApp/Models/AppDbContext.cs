﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeOnBoardingApp.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) :
base(options)
        { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Country> Countries { get; set; }
        public DbSet<Department> Departments { get; set; }


        public DbSet<EmployeeAcademicDetails> AcademicDetails { get; set; }
        public DbSet<EmployeeAddressDetails> AddressDetails { get; set; }
        public DbSet<EmployeeOtherParticulars> OtherParticulars { get; set; }
        public DbSet<EmployeeSalaryBreakUpDetails> SalaryBreakUpDetails { get; set; }
        public DbSet<EmployeeWorkExperienceDetails> WorkExperienceDetails { get; set; }
    }
}
