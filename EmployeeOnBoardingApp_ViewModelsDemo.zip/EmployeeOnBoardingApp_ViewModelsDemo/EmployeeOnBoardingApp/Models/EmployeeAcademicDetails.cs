﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeOnBoardingApp.Models
{
    [Table("EmployeeAcademicDetails")]
    public class EmployeeAcademicDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int EmployeeID { get; set; }

        public string Qualification { get; set; }
        public string UniversityName { get; set; }
        public int YearOfPassing { get; set; }
        public int PercentageScored { get; set; }
    }
}
