﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeOnBoardingApp.Models
{
    [Table("EmployeeOtherParticulars")]
    public class EmployeeOtherParticulars
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int EmployeeID { get; set; }

        public string BloodGroup { get; set; }
        public string MobileNumber { get; set; }

        public string AlternateNumber { get; set; }
        public string MaritalStatus { get; set; }
        public string Gender { get; set; }

        public DateTime EarliestDOJ { get; set; }
        public int CurrentSalary { get; set; }
    }
}
