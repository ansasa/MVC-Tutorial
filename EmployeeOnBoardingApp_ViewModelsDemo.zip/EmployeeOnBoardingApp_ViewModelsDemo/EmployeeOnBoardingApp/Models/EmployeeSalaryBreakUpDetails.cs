﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeOnBoardingApp.Models
{
    [Table("EmployeeSalaryBreakUpDetails")]
    public class EmployeeSalaryBreakUpDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int EmployeeID { get; set; }

        public string SalaryComponentName { get; set; }
        public int SalaryComponentAmount { get; set; }
    }
}
