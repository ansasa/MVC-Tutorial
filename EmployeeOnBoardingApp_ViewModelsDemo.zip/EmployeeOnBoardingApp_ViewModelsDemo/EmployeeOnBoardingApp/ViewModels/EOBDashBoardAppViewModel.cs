﻿using EmployeeOnBoardingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeOnBoardingApp.ViewModels
{
    public class EOBDashBoardAppViewModel
    {
        public Employee Employee { get; set; }

        public EmployeeOtherParticulars OtherParticulars { get; set; }

        public EmployeeAddressDetails AddressDetail { get; set; }
        public List<EmployeeAddressDetails> AddressDetails { get; set; }

        public EmployeeAcademicDetails AcademicDetail { get; set; }
        public List<EmployeeAcademicDetails> AcademicDetails { get; set; }

        public EmployeeSalaryBreakUpDetails SalaryBreakUpDetail { get; set; }
        public List<EmployeeSalaryBreakUpDetails> SalaryBreakUpDetails { get; set; }

        public EmployeeWorkExperienceDetails ExperienceDetail { get; set; }
        public List<EmployeeWorkExperienceDetails> ExperienceDetails { get; set; }
    }
}
